from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

from ..normalization.schema import canonical_hash
from .schema import (
    EVIDENCE_BUNDLE_SCHEMA_VERSION,
    KNOWLEDGE_MODES,
    EvidenceContractError,
    RetrievalBudget,
)


TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:[-_.][A-Za-z0-9]+)*|[\u4e00-\u9fff]|[^\s]", re.UNICODE)


def count_tokens(text: str) -> int:
    return len(TOKEN_RE.findall(text))


def _quote_hash(quote: str) -> str:
    return hashlib.sha256(quote.encode("utf-8")).hexdigest()


def _required(record: dict[str, Any], field: str) -> Any:
    value = record.get(field)
    if value is None or value == "":
        raise EvidenceContractError(
            f"Retrieval candidate {record.get('record_id')!r} lacks {field}"
        )
    return value


def _provenance_locator(record: dict[str, Any]) -> dict[str, Any]:
    locator = record.get("provenance_locator")
    if locator:
        kind = str(locator.get("kind") or "")
        if kind == "pdf_page":
            page = locator.get("page")
            if not isinstance(page, int) or isinstance(page, bool) or page < 1:
                raise EvidenceContractError("pdf_page locator requires page >= 1")
            return {"kind": kind, "page": page}
        if kind in {"markdown_section", "markdown_document"}:
            return {
                "kind": kind,
                "section": locator.get("section"),
            }
        raise EvidenceContractError(f"Unsupported provenance locator: {kind!r}")

    source_path = str(record.get("source_path") or "")
    if Path(source_path).suffix.casefold() in {".md", ".markdown"}:
        section = record.get("section")
        return {
            "kind": "markdown_section" if section else "markdown_document",
            "section": section,
        }
    page = record.get("page")
    if page is None:
        page = record.get("pdf_page_index")
    if page is None:
        page = record.get("page_start")
    if not isinstance(page, int) or isinstance(page, bool) or page < 1:
        raise EvidenceContractError(
            f"Retrieval candidate {record.get('record_id')!r} lacks a valid locator"
        )
    return {"kind": "pdf_page", "page": page}


def _locator_key(locator: dict[str, Any]) -> str:
    return canonical_hash(locator)


def _normalize_candidate(record: dict[str, Any], channel: str) -> dict[str, Any]:
    quote = str(record.get("quote") or record.get("text") or "").strip()
    if not quote:
        raise EvidenceContractError(
            f"Retrieval candidate {record.get('record_id')!r} lacks quote/text"
        )
    locator = _provenance_locator(record)
    source_record = record.get("source_record") or {
        "type": record.get("source_record_type") or record.get("kind") or channel,
        "id": record.get("source_record_id") or record.get("record_id"),
    }
    if not source_record.get("type") or not source_record.get("id"):
        raise EvidenceContractError("source_record requires type and id")
    node_ids = sorted({str(value) for value in record.get("kg_node_ids") or []})
    edge_ids = sorted({str(value) for value in record.get("kg_edge_ids") or []})
    path_ids = [str(value) for value in record.get("kg_path_ids") or []]
    normalization_mappings = {
        str(item["mapping_id"]): item
        for item in record.get("normalization_mappings") or []
        if item.get("mapping_id")
    }
    candidate = {
        "record_id": str(_required(record, "record_id")),
        "paper_id": str(_required(record, "paper_id")),
        "document_id": str(_required(record, "document_id")),
        "document_type": str(_required(record, "document_type")),
        "page": locator.get("page"),
        "provenance_locator": locator,
        "quote": quote,
        "quote_hash": _quote_hash(quote),
        "source_record": source_record,
        "kg_node_ids": node_ids,
        "kg_edge_ids": edge_ids,
        "kg_path_ids": path_ids,
        "normalization_mappings": [
            normalization_mappings[key] for key in sorted(normalization_mappings)
        ],
        "retrieval_channels": [channel],
        "source_score": float(record.get("score", 0.0)),
        "evidence_validation": record.get("evidence_validation") or "unknown",
        "review_status": record.get("review_status") or "unknown",
    }
    if record.get("kg_paths"):
        candidate["kg_paths"] = record["kg_paths"]
    return candidate


def _merge_graph_paths(current: dict[str, Any], row: dict[str, Any]) -> None:
    if not row.get("kg_paths"):
        return
    paths = current.setdefault("kg_paths", [])
    for path in row["kg_paths"]:
        if path not in paths:
            paths.append(path)
    paths.sort(key=lambda p: (-len(p.get('edges', [])), tuple(n['id'] for n in p.get('nodes', []))))
    del paths[3:]


def _rank_channel(records: Iterable[dict[str, Any]], channel: str) -> list[dict[str, Any]]:
    ranked = sorted(
        [_normalize_candidate(record, channel) for record in records],
        key=lambda row: (-row["source_score"], row["record_id"]),
    )
    unique: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for row in ranked:
        key = (
            row["paper_id"],
            row["document_id"],
            _locator_key(row["provenance_locator"]),
            row["quote_hash"],
        )
        if key not in unique:
            unique[key] = row
            continue
        current = unique[key]
        _merge_graph_paths(current, row)
        current["kg_node_ids"] = sorted(
            set(current["kg_node_ids"]) | set(row["kg_node_ids"])
        )
        current["kg_edge_ids"] = sorted(
            set(current["kg_edge_ids"]) | set(row["kg_edge_ids"])
        )
        if len(row["kg_path_ids"]) > len(current["kg_path_ids"]):
            current["kg_path_ids"] = row["kg_path_ids"]
        mappings = {
            item["mapping_id"]: item
            for item in [
                *current["normalization_mappings"],
                *row["normalization_mappings"],
            ]
        }
        current["normalization_mappings"] = [
            mappings[key] for key in sorted(mappings)
        ]
    return list(unique.values())


def _fuse(channels: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    fused: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    rrf_scores: defaultdict[tuple[str, str, str, str], float] = defaultdict(float)
    for channel, rows in channels.items():
        for rank, row in enumerate(rows, start=1):
            key = (
                row["paper_id"],
                row["document_id"],
                _locator_key(row["provenance_locator"]),
                row["quote_hash"],
            )
            rrf_scores[key] += 1.0 / (60 + rank)
            if key not in fused:
                fused[key] = row
            else:
                current = fused[key]
                _merge_graph_paths(current, row)
                current["retrieval_channels"] = sorted(
                    set(current["retrieval_channels"]) | {channel}
                )
                current["kg_node_ids"] = sorted(
                    set(current["kg_node_ids"]) | set(row["kg_node_ids"])
                )
                current["kg_edge_ids"] = sorted(
                    set(current["kg_edge_ids"]) | set(row["kg_edge_ids"])
                )
                if len(row["kg_path_ids"]) > len(current["kg_path_ids"]):
                    current["kg_path_ids"] = row["kg_path_ids"]
                mappings = {
                    item["mapping_id"]: item
                    for item in [
                        *current["normalization_mappings"],
                        *row["normalization_mappings"],
                    ]
                }
                current["normalization_mappings"] = [
                    mappings[key] for key in sorted(mappings)
                ]
    for key, row in fused.items():
        row["score"] = rrf_scores[key]
    return sorted(fused.values(), key=lambda row: (-row["score"], row["record_id"]))


def _format_item(index: int, row: dict[str, Any]) -> str:
    path = ">".join(row["kg_path_ids"]) or "none"
    locator = row["provenance_locator"]
    if locator["kind"] == "pdf_page":
        rendered_locator = f"pdf_page:{locator['page']}"
    else:
        rendered_locator = (
            f"{locator['kind']}:{locator.get('section') or 'unspecified'}"
        )
    canonical = ",".join(
        str(item.get("canonical_value"))
        for item in row["normalization_mappings"]
    ) or "none"
    return (
        f"[{index} | paper={row['paper_id']} | document={row['document_id']} | "
        f"type={row['document_type']} | locator={rendered_locator} | "
        f"record={row['source_record']['type']}:{row['source_record']['id']} | "
        f"path={path} | canonical={canonical}]\n{row['quote']}"
    )


def build_evidence_bundle(
    *,
    query: str,
    mode: str,
    budget: RetrievalBudget,
    rag_candidates: Iterable[dict[str, Any]] = (),
    kg_candidates: Iterable[dict[str, Any]] = (),
    experiment_mode: str | None = None,
    retrieval_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if mode not in KNOWLEDGE_MODES:
        raise EvidenceContractError(f"Unsupported knowledge mode: {mode}")
    if mode == "small_kg_rag_shuffled":
        raise EvidenceContractError(
            "small_kg_rag_shuffled is reserved until a frozen corruption manifest exists"
        )
    channels: dict[str, list[dict[str, Any]]] = {}
    if mode == "rag":
        channels["rag"] = _rank_channel(rag_candidates, "rag")[: budget.candidate_limit]
    elif mode == "small_kg_rag":
        rag_limit = (budget.candidate_limit + 1) // 2
        kg_limit = budget.candidate_limit - rag_limit
        channels["rag"] = _rank_channel(rag_candidates, "rag")[:rag_limit]
        channels["kg"] = _rank_channel(kg_candidates, "kg")[:kg_limit]
    ranked = _fuse(channels)[: budget.candidate_limit] if channels else []

    selected: list[dict[str, Any]] = []
    paper_counts: Counter[str] = Counter()
    used_tokens = 0
    for row in ranked:
        if paper_counts[row["paper_id"]] >= budget.max_items_per_paper:
            continue
        rendered = _format_item(len(selected) + 1, row)
        token_count = count_tokens(rendered)
        if token_count > budget.context_token_budget:
            continue
        if used_tokens + token_count > budget.context_token_budget:
            continue
        row["token_count"] = token_count
        selected.append(row)
        paper_counts[row["paper_id"]] += 1
        used_tokens += token_count
        if len(selected) >= budget.item_limit:
            break
    context = "\n\n".join(_format_item(index, row) for index, row in enumerate(selected, 1))
    bundle = {
        "schema_version": EVIDENCE_BUNDLE_SCHEMA_VERSION,
        "query": query,
        "knowledge_mode": mode,
        "experiment_mode": experiment_mode,
        "budget": {
            "candidate_limit": budget.candidate_limit,
            "item_limit": budget.item_limit,
            "context_token_budget": budget.context_token_budget,
            "max_items_per_paper": budget.max_items_per_paper,
            "tokenizer_id": budget.tokenizer_id,
        },
        "candidate_count": len(ranked),
        "selected_count": len(selected),
        "selected_token_count": used_tokens,
        "items": selected,
        "context": context,
        "context_hash": canonical_hash(context),
        "retrieval_metadata": retrieval_metadata or {},
    }
    bundle["bundle_hash"] = canonical_hash({**bundle, "bundle_hash": ""})
    return bundle
