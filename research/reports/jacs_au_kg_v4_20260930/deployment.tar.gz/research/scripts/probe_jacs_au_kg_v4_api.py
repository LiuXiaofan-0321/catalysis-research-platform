"""Validate both effort payloads on a compute node, without logging credentials."""
import argparse
import json
from pathlib import Path
import time
from catalysis_research.experiments.jacs_au_kg_v4 import load_config
from catalysis_research.models.glm import GlmClient


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();c=load_config(a.config);start=time.monotonic()
    response=GlmClient(timeout_seconds=c['api_timeout_seconds'],retries=0).chat_json(
        model=c['model'],thinking=c['thinking'],reasoning_effort=c['reasoning_effort'],temperature=c['temperature'],
        max_tokens=c['generation']['max_tokens'],system='Return JSON only.',
        user='Return a JSON object with ok set to true. This is a connectivity probe; a short response is sufficient.')
    report={'ok':response.structured.get('ok') is True,'model':response.model,
        'reasoning_effort_requested':c['reasoning_effort'],'max_tokens_requested':c['generation']['max_tokens'],
        'client_timeout_seconds':c['api_timeout_seconds'],'finish_reason':response.raw['choices'][0].get('finish_reason'),
        'usage':response.usage,'seconds':time.monotonic()-start,
        'effort_verification':'Requested payload accepted; provider internal effort cannot be independently measured.'}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not report['ok'] or report['model']!=c['model'] or report['finish_reason']!='stop':
        raise RuntimeError('Compute-node GLM effort probe failed')
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
